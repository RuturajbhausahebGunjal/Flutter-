import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Food extends StatefulWidget {
  const Food({super.key});

  @override
  State<Food> createState() => _FoodState();
}

class _FoodState extends State<Food> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 120,
                ),
                Text(
                  "Food Style",
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 100,
                ),
                Container(
                  height: 30,
                  width: 30,
                  decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(8)),
                  child: Icon(
                    Icons.add,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Stack(
              children: [
                Container(
                  height: 100,
                  decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(18)),
                ),
                Container(
                  height: 130,
                  width: 100,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          alignment: Alignment.centerLeft,
                          image: NetworkImage(
                              'assets/boyz-removebg-preview.png'))),
                ),
                Center(
                  child: Column(
                    children: [
                      Text(
                        "Hey good Morning",
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        "Ready  with your Style?",
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Text(
                  "Breakfast",
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                ),
                Text(
                  "(Fastest food)",
                  style: TextStyle(
                      fontSize: 15, color: Color.fromARGB(255, 147, 146, 146)),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          height: 130,
                          width: 220,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShwqUZC7ZonFi1dhS3gg8iqGIdTTXSUbvR-1396RvaF7bk5f0y2COAyLoSliw4LEqyjUs&usqp=CAU"),
                                    fit: BoxFit.cover)),
                          )),
                      Text(
                        "Freshes Tamogoyaki",
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        "A delicious egg food from Japan",
                        style: TextStyle(
                            fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.timer_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "10 min",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.star_border_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "4.5",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.car_crash_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Delivery fastest",
                            style: TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 13,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          height: 130,
                          width: 210,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-35yKknxZcBnVEoLY1ROC4-wyY-NT4sfwHg&s"),
                                    fit: BoxFit.cover)),
                          )),
                      Text(
                        "Okonomiyaki",
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        "Unagi the Japanes femous food",
                        style: TextStyle(
                            fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.timer_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "10 min",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.star_border_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "4.5",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.car_crash_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Delivery fastest",
                            style: TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          height: 130,
                          width: 170,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwwXPThWZTzBu9COS_fb035E6vg1vpd6hrulsjThpcG0xJF0-3J1zY_8SO05S-nlxfesI&usqp=CAU"),
                                    fit: BoxFit.cover)),
                          )),
                      Text(
                        "Freshes Tamogoyaki",
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        "A delicious egg food from Japan",
                        style: TextStyle(
                            fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.timer_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "10 min",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.star_border_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "4.5",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.car_crash_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Delivery fastest",
                            style: TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Text(
                  "Lunch",
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                ),
                Text(
                  "(Japanese food)",
                  style: TextStyle(
                      fontSize: 15, color: Color.fromARGB(255, 147, 146, 146)),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          height: 130,
                          width: 220,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRm3uMFkjNiesPebuBMl1wpK7Pr_YPcUgl1DA&s"),
                                    fit: BoxFit.cover)),
                          )),
                      Text(
                        "Tempura",
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        "A delicious egg food from Japan",
                        style: TextStyle(
                            fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.timer_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "10 min",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.star_border_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "4.5",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.car_crash_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Delivery fastest",
                            style: TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 13,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          height: 130,
                          width: 210,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSExIWFRUXGBYYGBUVFhgYFhYXFxYWFxUXGBgYHSggGBolHRYVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0mICUtLS0tLTUtLS8rLS8tKy0vLSsvLS0tLy01LS0tLS0tLS03LS0tLy0tLS0uLS0tNS0tLf/AABEIAL4BCQMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAQIDBAYHAAj/xAA9EAACAQMCBAQDBQcCBgMAAAABAhEAAyEEEgUxQVEGEyJhcYGRMkJSocEHFBUjYrHRcvAzQ1OCkvEWY+H/xAAaAQACAwEBAAAAAAAAAAAAAAACAwABBAUG/8QALhEAAgIBBAECBAYCAwAAAAAAAAECEQMEEiExQRNRImGBkQUycaGxwRTxQlLw/9oADAMBAAIRAxEAPwDmdpX1V0W0BImu1eEPDi6e2JHqqp4I8HpplBIlu5rS8V16WFkkClhj9frltKSTFci8b+K/MJVTio/G3jMuSiHFc9a6XaSauiWE7Vyc1Yt07hXCL96Bbts3vED61seHfs41LwXYJ8poWMTMotShgK6Jp/2Xj715vlFWR+ye03/Of6igcZB+pFHLbusAoZe1hLV1zV/sXnKag/8AcAayXGf2Wa6ydyhbg/pwaKMGuwZZE1wZlXqUNTb2juWjtuIUbswikUUwWhzLULJVhKVkmhsIpkV4Grb6J4mMQTzHTnUNywy8wR1qKSfTAtDQ1PD1HFLRBEkVV1yUb4VwS9fMKh+MVstD+zgtbPmHMYodystx4OTVY02tdORqxxjhT2LjIw+ySKHUwSbbgvjW5bgFjHZsj60T4hxbz1G1AfYGucKaktXWUyrEfA0EscZdoZHLOPTOk8H0lsBjdbaOi0J4oLLXNqMKzun8RX1wSHH9Q/UVKeNWX+3Yg91NIlpIt2mPWraVNBBWRS294A5CaiTUCdyn51Qe5pXzudT75qO1btqZW6COxoHo/mFHV/I1triIIhjjvV3w1qpLhZhutYu9cQn7UDrBonw3jiWRsDwvwzSHpZLoetVBhTjGj8tiVImhNjWqreud35Cna7jVpshyTUGn1ummWb41UNPLnci554vpk/EbiEbkJNe8t6mfi/D1QBVYnrUX8e0v4Wolhl4QPrx8s69x7xTY0qmWE9hXHfFHjJtQxgmO1ZTV6y5cO53LH3NVq6KRzrJLt0sa6P4P8DIEGo1XXIQ9Pj3NYjw1ZVtVYV/sl1n9K7N4wc2yi8k247VJOkWlyXtLr7SDbbQACiNjiM9a54uvPeKuafiwHWk+oOWKzpNjWCr9q/Nc803HoovpOPT0qlniU8EjcW9QakLzzrI3vFVm0su2eijJMdBQi9+0+yMLYfd2YgLPTImQfaj9aHuZptRdNmr8Q+GbGrQq6CehjIPsa4H4k4Q+jvtZbI+6e4ruXCPGWnvuUkpkbS8BXkTg9DgiD2rnn7SriXtV6RuNtZIAPv1HwqPLDbuTsimuzE6PRs8kDCiWPYd6tWgE+OM9MjMfUYqXT3dzKnqVWCiFiGDEZMkSO3zrX+GvCVsl3ubm9Upu9J5zyHWeuekVztTq1BXICWWU3tiY3SrbJVWJ3clwB9qGg/Ezn4Vr+CeDk1NlvMYpE7GQ8wQJ3AiZ/wA1rD4d07ApctKd0lSVG4SZOec+/tTrNsaZvXdJUgBQx9QEZ5D1GYrEs/qVKPAUcLTtmA8R+B009u41vzHcQVUxAUfabH2qd4Q8FNcIe6Mdu1dH4lpvPtyituEEbvSuRn3+NQ8L14sWz5u2FJymYA79634c8/y5PuaoL2CXDuEW7IAVQKvkUG0vinS3OVyP9QIpL3ifTgwCzfAf5rT/AJGGK/MvuM/x80n+V/YyP7SOAA/zlH+quT63h5WvoHUcY0t9CheJH3gRXM+N8F9ZW36x0K5xTI58b5Ul9wJ4Mi4cX9jnW2Kca0mu8L3xJCT7AgmgWp0jp9pGX4gijhmxz/LJP6i54ckPzRa+hWNMNPNMNNFDaYac1NqEPUler1Qh6vV6kmoQQ1PVeasVCEMUsUzdXgJqgiRLpBBBggyD2I5V2/wn4hscR0otaobXXG7oT3B6Vw9bddK/ZagO626bh2qcE57DXGPAuoUlrDC6naYb/BoIOFai2Ye06/8Aaf0racU1x0wZrd4245KfUO5x2A60Mv8AjrVQEVELmIhRuJmNqq0g9ZNZM2PGu3yMWs2dg2xaI5g/Q07V8VFsEJlo7jE4GOpqhc190hle76iWLBR6Tv2FpHSSggdM9CZEWrV5yzDbsZirbpLenJYjlEY7nbWH4buyZNa5xqCr5j9Rqj6TbJLlmBxAxkEd9x7+1I1+2LcOj+YTsLFvs/Ij40f4RwGTBILbQYgSsyVPwJEf7xo9TwDTovmG2u7eGa4R6yW6AgYX1f5pUs0bqvqYFjZhuG2PMuC2zqVZlMsDkgk7TJwIJ+OK3t7wp5pDLcYKZmPpHwozoNDp2QFVj1yeeZEHPUEQKLnUolklc8wByz29qU25u26pX/A2GP3OP8V4A9i+11UBRZYFjPoGMknnj84FdG4NrkWxbuXTEoCSRBWQCBHMz7ZoZxbhbakEFQ24ZZhIhScBAeWTie3asXd3qPK3uUQtCuxABBzE5A7DkMRyyLSy16na/gq/Sdm34j4v05X0LdaSAGVYA5iPVGccudB9Z4nXBaSFaR/UyjkCW9M84rNn0qitsMLJJJJLsSVgZk5PaAc1RuaY2tQDdVWZjuDKdwEwQAYGRnPvTIafErr/AGMWabN6vj22FEo43ZUYI7EGYODigFziqurzcKuVlfsw5JO4MDyHY0FbSMN0AyAYk9CSwA7fH2qhb0aW1D3CWg4Az05CcDnzp3pQlzyHDLkg7RquB2muKSMDkWPfsKPWtGo9z3P+K5z4Q4m1nVKpHpvHacklecQJiZ2iSDiunB5rBrMEoT46Z6nR6n1sdvh+Ss+kQ9IpHGwYH+atbvnTGrE0+pGtMGm4TSPBBDCR2ORS8QQoN6zHUfrUFm9TNvlB2mZXjnhaJezy5lOo/wBP+Kyb2iJrrJMEHpWZ8YcPVYvKAASFfpk/Zb9K7Wg10pNY8n0ZwvxD8PjFPLj+qMM60yKLXNN0Ig9j+neoH0Rrs2cSgeRTautpTUJ05qWSivSVP5B7V793PapZKIKsV793NT+RUslFRbdT27NS+VVrSWZoWxiiLptKBk0e8J8daxqBsEzzHsOZoHr720RV3wtpDJvEA52AHuRJMT2x8z2pc5bYuQOWW2LDvGOJXL7m42Z5wDAAyFC8oIgEnoTPQUGbUdyR7DEAxPLrjn8aJ6Fp9KKTs3DABkgjAj2k8u3tVfU6JnO8iFIhRABIEDAJxk1z3O5UzDCrtkVkwdqEsIGSMgzJk9a0XBlVSCYIuMTBHIxme+f70JTS2rZCm564QiD6ZKsWRsYJjHwp2rcm3tV4ILFcwWUAhvnK0ucd/HhmiLiGPBbG5qbpa4SUZl28h5ZMwPgZIPvWs4uz3QLaMVUsdziPSF/CD1JI+lc9/ZraddWyH7ttwes7SsCesE10C+IUgzBB+Mnr8aXqKhKvBbkS8X4vbsW7agmGkLDSysnPJyffP96D3fErDcFUkAAA8t0zMBuREnnVPitqymmtW9xVluNcS3JPOQzEmSOZz1M+9X/C3CjfVXdf5cSDgj4YPP36fKsslFL1SKT4RdbxUuntq3lMcATH0AJ58jmgWn8U2WvN5tkpbukAsSMMBgkDoSTJ6Y6Ct8iKLZ3QFWBBG4Dbifc0D4twfR7c2ELEAkqgDerqPfIoY6mEq3r9A5Y5UV14ZbFyFVesbxIjqf8AfvQrxZpRcK7QAEBjaCByHL6UZ4DqXVrllxi3c2qxIJa2YKTH3lkgyO1FdZpgZwKeo0vhYWOrMPxDTk2hjLASesDp9aHfw4HaCAEVdzE4EjmSfwgSa0XGNQCSAMCB9KH3birZYMm/cIYEEgJMCfcmnwmlyzTjwuTozfDr9k3C4QfalSRlYELHY85+PtWme6LgAJgjke36HpWRGia3cIQHaDIB+0Pb3iiVnWAGDz58j+VTLHc90WdzFPHGOw2XCjtt+XuG8SfVBVh7Y9uX0orY4WjfzLtsoCB6VdlAB+8DPKawKcVU8mzjE/7itBwPxIGZNNfu7Lf3WOFJmFQt0kkdelXBuTqUeRGbGoR3Qlx+4S4lwN4IsPv/APruEZH9Lj9aydi21u55d3+Wf6uXtB5Gurpp7ajYQu2YHX1HMTUfFOE2rlvZcT09DAMfWino0064E49dOLp8mHWFGOfvUWotLcXa6BlPMMJBqvxjht/SsfLPmWxkK2Rt9mqPhvE0u4kqw5o2D8u4rkz008fJ1seox5FQO1/htCp8r0f0HKfIfd+VZbUI9ptjqR2B5H/S3X4V0xBVTiGjS4CrqGXsa16b8TyY3tycr9zJqfw3Hl5hw/2OfeYnf5Gonup3FR8QseXdey+Qp9Lddpyp98RS6ThIuHaD6uYH4h3H+K9FFqSUl0edlFxbiyO5qkFQPrR2oi/hlx0NR/8Ax9uxqcFcgm5qieVP8xqKrwBu1WP4A3artFUwYRRDRgBaovVzRXARFAxsSlq7Za6F71qdDZi2q2wS7Aw0iB7yRjr16UIuWwN1zqqmPicf2mj/AARfMtkWzMIoDDnhfV09IP61m1U9uKzLqX4DT8NTSotz/iF9qlkyQzYMEgmICn/c0E4zbv32a5EJLBo9IBMAYHaDj3Oan1RMi15l0NLGSBKEclBM5gTHanXdBfu22QXCqquFA5iSzSRzmeftXMhKmpNq/wCjPRnNewQqgaQApBMAlsExznMmrPD3Ozc3rYqY3cwqyQM+0/WnX9I9tSdo23AV9QBYQ3PGFPpPL8RoTfkKEyWYnPtAx8gAK2KpqrGRVo03ANQuHB2nadzAkCCehGcwD8/ailrjZV0ttLB95IAO8TLAZ7mZ9iKp8D0gTT7ys/DngdP89Kt8O4Rse1cfBKsZ6gsxJMdfSVPzrNOKbd9D8WJSdAc3G1GoeJBdwizPpUAKMdAAJ+tdk4faFi1asAelQFx1I5zJ5kz9a43qOKixf8xApZTM7RluU5rU6TxgLzWz6Vb7ymSvynpWfUQyOK2Ljg2R0zxtm11WluP6Qdqs09ARHvkSR7VnL7C01y014+kE5MEr9oEkZxJkRGB8Km1OoubDdUzGQB6SFyBgyYPyisLx2419x6XGSVXa2JAJMkZyORM0nFi3PbJC8mN1uiWtPrt2ut20ubgzSzrBBIyGIiIEY+E1vNdrgEOcmuY6TTvYub3QqQcOB6WJ9+VENVxZriMJZbgjZ9mCJzg9YroSilFKIuNR5kF7nqJ7Dme1WNZpbo0130GblxRA5qqKSB9WqodSCsFdrQA0iRlcsFJg95mq+m41ds21tl/QJJhQzZ5kSYoYON0zqY4Sj4BKXCHEK3pEDBJ3ZiCMyPyipNZdDIQ6EuB9pCFvSJgE9QTiD3mm8Mv/ALwwH7ztbcVDFtpEkxgcvlRjSeEr63GvXdSHUiTC/eHTcMchz6z3zTIxcbft+4WRxl8L8lPw94buXE8x2B3ido5r0yeROc1a1/DDbBUbSJyrAEe4I7dqDazSbLiXQtxvKbcEDsowZkDpn61J4g8QJqUKgGzdLAEMMvbPUEQF7HA+c1e31fii/wBRe70I1JcLoKWeMXtOi3LEOFIm0ZaQPwENgx7dKM8K/aBpdRc23t9ph+LCyTERMz+nOg/BPDS+UsbrbCTltwJJJnBEDlio+McI8v0FQ3p3EKQGGYknrkzA55xR79qpq/mXs3O7r5G01vE7LKixuBfbIxAY+k1n/GnhkKFvW4ENlgYZSeXM4rIvxc2tu0tbExKQSpUzndMHl06mK6P4Z8T29abtpwqTlRPMHBGQJ6VahuXPb6Lk9j46XZkeGcSP2Lg9Y6xAYDr7HuKt6rVqql2NQ+IOEmw7Wzjqre3MEfA0L4Lon1tzy7jhQmWgwY+6QPfv0iuctH6mSlx7o6UdXGMLl9H7mK49rjd1DP8AAY9q9pb5EZIzII5qR1FdN137MtI4UW7j22gS59XLnIxk96wvijw7+6ajyFcuNqsrFdszMjsSI6d69FCCjFJeDzmTJvm5PydD8G663rUKOAL9sAsOQdelxfboR0PxFHX4JaHOK4xw3V3bLhkJW4mVPcH7SH2IrSv42dsqJETk5+FLyWukXBJ9s3F7Q2V9/hVXdZ/DXPv/AJRediSYFQfxy7+OlXkGVAFmomkZGKlU0pzWgUTWrxezcnmI/WrfhLVEK1vzmQz6Etr6icFmYzgDp8+VVtAuHT8Qx8RNT+FbIS4zsuNu0MCZBM+naOcx+XyoNQk8TM+VWazTI1pWICfdLFiSTM+klsiZyateHuM7dR5Rn1nbynPOJExQrR6hU3sy+iW3cziSJHWQRE/qaK+F9TpbIfadrO0s0z6YB2yOWTke4riSi426d+DLfIX4np9OMSO8dAawXiDRg3ALYktgAdyY+Q6k1sPEmuswsesn7ysMD5czWYu8UC/YWPcwTQ6dShLcPhHyaRylnTrbZhC5Y9zif7VXucVa4o1DYVvTaXElZ9b/ANOFgYnPLGcjxDiBb7bYnPwrWaW4p0/mW2B9G23sErBEEGZ6CD1pyxyUbl5N+lglLkw3GdX5lxmIAJYmAIGTOPzqLTPcV1IHX9DFaO/wO/d3XrdpRbM+gsN0LEs0DCyYkgT2xVXT8AvnCqR1HWBygHqK2epCMabRrlCUm2jbeH+NjyhuaW9IO8SZjB7Rg0ZfU2b+AoD45Rtb3joa5+eDX1UBSZJBgA9iIMnlnnU+i1+pt3bdzaSyGGt5CMkESzTzE4x0FZHFSfEg+YKtrNxd4apBTk2QVOZB7E5rH8d8K3c7Lr45enMj+qRHxitlY8SWrig3bBkdcRM4xVfV8d01wMDutKDtNz7ik9wTjpyFWqTuDsXkjHj1eDmms4dcYkNfDXV5qXl8e04qfhV57RHnLuXvzInvWyu8Lsvca4fKLQIdApX7ODuU4kCKD3dDdGbqgrMo6jDL2IHIxB+dE57k0/H3Hx+FjeL+FLVxbl9Lg8tFJZwI3EAnagME/nzFDvC3HWtW/KmbeR5ZPIEyfqSfrU2usMVhbp2RhZgSTJzHucUZ4VwTSeUAbnrg9IdSe458+oo9y2VZmUcnquUvoGbul83+ZGSBBBksesrJyfaM1jvFXClZuTMwBJ22zvUDqR95TjlNXNJZfQ3DEsGIJgk7sRPUTHUVZ41x3+R5lt4uIygbvtqpBBggCean2zS8Sip2h2ST9P4l/ZY4DxuxcRLbXbaXLYg4KwoEBgVU7uxU5FWuMaq01ksl0M4AAE/a9UzHsJrLcLuqH9SIfKWdyCBcDYJYkSzyeZycGpneyzM5QgkTzEDoDHxj60eSS5iiYraUgXq9NcyGQqTmCv6nrQvS3TaugbiGwQRzFbDhrTutEgs5VtzcyAD6ZOes86Ganh3mXGEAHawUbS2faJjAOe00WOaT2+AsnPJqLHiC3qUNvVttJSUYgn1AYIMejAyDIM1ljZZH3q0RJVwZg9p5H4GpOJXVS4pDKWHMAggECGGOdUf3/bcmcH7Q6EHmDNB8Td+QW0lXg3XDfFKCyHuAzBnapbIMRj361l/2jalDdssVuq5Un1SE24gLmJnnHz6VFYvkMqWj6myAIggjMg4rTXdAbuna/e23XFq4EtgYViuTu6tiMe9dXDPcqOXmhtdmAtgPy50JA2u6/P60Y0qYBHag/EyRdMdiPzpklaAi6ZEimTmpdlVdrd6k2HvQJDLCn8Nuj7tKNDc/Aa0xup71F5y8pNY1qJexvemh7mfay6Q8EQaW7e8lxcAm25UtHMROAenOjHEEDWmz0mPgZoNYcEFH+yfyNacUlkg0zFqceyXBNevAWQfLB3uNvpAJUMDBMxPL09j9JV1I8wsQNoi2i8iwkZEExzgx0oZdF22RbLEqWBByRGQIjPXpUjXULFnF1usFYBHInA9JhYk9jSXi2umYXErm6SWc3APs5BOJMBcHMAGka/cwZIBMZ69jnvUeq1KldoDYEgHGSILGIJI5Dnitv+zXgdq8r3du6MDeFMGIJB95j5HvV5ZRxwc2h+HG5ypcBTh/hoE21VFBZTDXACCVhiJz1j1Y5x0qjxDTAygcFhKghto+TDBGK1Q4HeG1FC7AuxQJEL1ERmczVheAXLattUQQAQy7gInlyjnXH9a3xZ3VjglToyGj4xctC2DaRmSQ0TLcsNmDynAFaXhniey5XzLYTEErII+WeVZ/ifCWt3gwUBD33FU74GY/tVLX8Ou3yGDDEgLyUEHnAEmabuUvKVlSTUeI2b7Ust2AkbOjAdD3oTq9RpFu+U171gBtrKeXLdgRP+aDcDv3bA2XLgYzj2H4Qevzq3qBYF3z7tuGKqC59QCgnoMz0wKSoJyd8+39BptJePcMWuHpcBCMjExEn3MgiM8udAfEnh9y02YYOIYH0wIglQDE9PpWk4FrrBVlVlkkhkf0n2BVsjEfWgGpS7cfy0UqVksxmBH2V3DkJmiinBpJciM7U+FyvcBaTSXtM+5Ha2MqbbLKMEJ6H/3k1pLPGrVz03UNuIJAbdbYjGJHpkDnkVZ0tlLsl1O9pO0mFU+2c8qzHH/D7AsQSEwBBPOJjPSm+pudz6GRxJKkFNRw8XdwsMA3JWIEiIglTg/InrVVtFdtWibm2+5XDgBSpElTHfI+lZDTarUacyhkEZUmRHXnyNEtL4k/eLgt328pergTt7SJmmrDL/jTQnIoz4kE9NxZ3XZdU+8AT2kfQYmMVTt2/WSCWHLH2hnEijd3w7j+TeW9B5D0sZ5QDz+RoPqrC2yQ6tIxBBkHr1xS3Hmuh6br3LjL5aSuwMZJIkGCI2kEx3x7mhHmliSwO45JJmfgT9Kfq75YSJnqTmf1qppNbv8AQ3OcT26/MVajKr7JuUeB54i9ohwoYgERPQjJU9/80w8SBUOAw2nn95T9ZBq5d06QQDMQR/UOsflWa1N4pdbaJEQQfoMU7FGM/wBUIySceS9e4ghM7WnPbrnOaordLsJGOw/v8an4dZe6wSACdxkjqIxz+lS/w4i4qA9RPfn+VPW2HAl7p8hLg9qHDLzyBJ+tbPhl0heX0Oc03g/g0qu+4wVOYnmc880Y0vAAylvOIB5bRDEdDmnYKl0Zs1rs5pZuLvuGIUO4C/0hjj+1Zu/fD3Cfj+ZopxlRp99lXLQWEnnzOT78p+dBrCkDcRg9a0N8CY9kpxU0ioJ+lSQKAYajyX70vlPV0g9qjJPauduZ1tpX8tqA3l2sVPQ1p5PagnG7XqDxT9POpUZdVjuN+xDavgjZcEr36j3FVNZw02/WPWh7EwekGDiM4r01Z0usa3yyDzU5B+I61uaT7ObQP0ukusNq2zzDFyIiBgbj0yTXQfAOsGkW7ZdoYuCJ57Sogx0zP1rMi2twRaum0x/5bH0E/wBLfdPsfrVTW2nthQyOt9WJ3k4ZCBj3II5jmCayajBPJFxfRq00oRafk7d/F/QpU5Wcin8P8Qh2hiAeR7HvXOfDGrv3StrDOwMBTyAEkt2HvXuM6q7ac2ymQeefyNclYNRCSa5X7HS3YWmn2dU1WgtuQUAKnmZOMdZPKgGv4CNw2sLecHO325VlOE+IrtsfbIPXqDR614le6gRoOQZjNDkcFfw1/AcIzXUrK/F7entWypYtdJBlfsDlMk85qjY8Qy482yjqqwGliw7YOOUirPGNGXu2tzbV/wCpHpEdx1NQX9PZHpQs7Tlzjd8ulXvio3S/QNq6sm0nCF1SM9oIo3GZOZ5jpj51T0HEr+iuNbZNy8mtsTnsR2PvTeHcV/dLpLK2xgdwj0k9Dyqvxzi7328xlHYbRkDoO/WjVKKlG7KdttPo2WnazetrdRSbZ5xh0PY+4odx7h93ywBdL2TJEmGBiINZDg/Hr+mcxIVvtKfsnpPxrUHjdq9Z2rv3TI6wes+1FLHStCozaZhNfoyhOWHtzFDdZpiIIUFjkMDnlMRRrit1vMgjP96DcR1C56Y5dCfhWnC5OhWSkbPwzq1vadSJ3WwA4AyBJ2OPaMe0Va1uthdtz1rkqzSWUnmQ3OPY4rHeDuP/ALtdJK7lYQQCMz8cVp7bC6WYYGfSM4+NK1OLbK4+fA/DPdHkx2u1jFiFUkDqcDnUNy3cT1kwT+vvWv4zo406tES2IiSBmCayvFLu4ED7sY75/wAf2p+J2kkjLltO7I31rxO7HyqnsGwvvzOBkkx1+FVolis4FbfwfZt2yC0ZgZxg8qdNxxISk8iK/hf+cTBKXT6AIJSOZkDPT8q3/BPCotxKJdO4+qNrL/V3J+Y+dErPhuxsVrNpUuBt29RDGZnPUZ5e1aPUam1pbPmai6lsKACzGJMRgcyT2GaF6Zzl8gVqdsa8g9raKy+cdw/qOMcvpWS8feNLenUWdOyl4mVIIQHlJHXMx9az/j39o41A8rTqVtg/8RhDt/pH3B+eelc1uOWrTjxqHRnnNy7H3bzXGkkkk9epNFLFxQNhyhxPYjFUOH2d1xVEc5zgYz+lGuJ6QKoMDP2oM57gdqZLE5wb9iY8ihIF6vTm2e4PI03cKsabUf8ALfI6E0X3J/0rdKjNLiY2WNvmAe8yk3+wpKa3yrmHWYhuVV16+YpEe4qyQa8oNEuHYDVqmZF1ikVqK8Y0kGYwf70HOK6eOakrOTlx7ZUSTV7TcWuINhh0/A43L8uq/KhwakJpqYmjWcD8QiySbF02CeaOPMtH4H7a0Z1vFGvpuu2Jgz5mmi6pnnuA9S/MVzeaks6hkMqxU91JB/KqaTLTa6Ndes23G626PAJZQ0MAImQYg+3saGWeK+VcG4nYevVaotxx2/4qpdjq6gt/5DNOTXackMUZCOUEOv8A4t0pE9NGQ+GocWdk0Gt3WAGRWWBDSCMjDUml4GisbgEqekj8q5zw/wAVNbwr2yv4WUoB8IwK0Gh8dgYe0YPPy3VgfrBrPLReRy1KNDxOz6D/ACAw6EzNZTVcPRSQlzZidpQlifwiMGja+NtIRDG4g/qQmPmKh4hxnh90A29Qgb+skf3GKxvTTi7av/3yNUNTHqwDxfQMqq3mK+4T6eY9jQ7R3th9JIYzMjEROR3qzxfiVsJ6HVj/AE5rO2+IsWmIHI+9Mx45/QqeSJpeMgMlq8rpyhliDu6k95xmshrbLXTAEH4846zV/U6ncotBYglt0jkYEc+n60/RWF3QbiKAQdxbHyjNNgpQ5Am1LgprobYt9m79jRTwo9x3uLyCW3PPJYL6QPmaqcXuIjAJcF0H1MVEAN2Hen+H9fZsFrt7fvJlQijbHWSfpRxjJq2rJ6sE6To0fH1CpbuCVHlwR0LAgg/HkPnWECsxkH1uSB7DqfpRHjvH/POPSOgx9fjQdNaFMgZHI9f/AMpmHDKK5EZ80ZPgJfwVVAByzED6mP1o/ptDodMrfvF8uTG22jFivcwvWe/asZf4i7cyT8TVRrhNOWK/zMS83/U6Pqv2nPbti1p7QER/Mu+phEQQnIfMn4Vh+Lccv6l/MvXWuN3YzHsByUewihtepiVKkJbt2LNOBpopRmoRB3gGntkFnubJMCBmBz+Gf7UfsaCz6ovn1CJOcdqwwLdDTvMb8Rq1OS6ZbUX2gnxHShGKhwxGQR1HamQPxn6UMLtMycVe/fT2FA78BqS8m28ztSq9Oa0B0pptVy+DsHnmpFWoimK8ye5qEHXtPvUqeR/L3rK67TFGIPStMHbvVbiNkXFg4bof99Kbhm4P5CM2NTXzMsaUGnXrZUkEQaimugmcyUaFam1400miBPE00mvE0k1CCGvBjSE0lQolF9hyY/Wl/e3/ABGoJpCahCyNc/f8hXv39+/5VWmmGoQstrnPX8qjOqbvUNeqEHtqG7n60wue9NNeqEPV6vUlQs9Xq9XqhD1epa9UIJUtsVGtPFUy0OakpaQiqLENTRUVTVZR0kWvemPPYVCls/iP1qUyPvH51xzuDWue35UgdetMu3D8ag872olEFssOB0qG4KrXLnsRUasTyOaNRBciDimm3iY9XfvQC6hBg8607aRsGfzoZxDSz7nt/wCqfiy1wZs+Fv4kCJrxpz24qM1rTMLiNammnmmGiBobNJNeYUhqFCzSTSV6ahBSabNepCahBaSaSkqEFr1er1Qs9SV6vVRD1LSV6oQWnItNWpkqMJIjbnTlFecUgqiDwKU0gpYqEEIjI+lS7hTKlgVCG8M8wR8Jpgd/amG90inBwMxXMo7Fkd+8w+7VC5q/aKJPdXsfrUOo042yQD/eii0u0DJPwwa+r96YmsKnl8ai1loCCJqJVJPTtWhRi0Z3KSYS/ie72+tNe/PLFUxImfypytPSkygvA1Tb7H3rSED9KHajSkcsj86Ik1VYUWOTQGSEZAxhSGrV5aqtWuMrMUoUNNNIpxpKKwKGEUhp5ppq7KobFIadSVCUJFJTqQ1CUJXq9SVCHq9SE0lQoWa9SU4VZBVqVaiqQULDR56970j15TUKfY8GvU2Ip1QgoqeKgFTTUIf/2Q=="),
                                    fit: BoxFit.cover)),
                          )),
                      Text(
                        "Donburi",
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        "Unagi the Japanes femous food",
                        style: TextStyle(
                            fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.timer_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "10 min",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.star_border_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "4.5",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.car_crash_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Delivery fastest",
                            style: TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          height: 130,
                          width: 170,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwwXPThWZTzBu9COS_fb035E6vg1vpd6hrulsjThpcG0xJF0-3J1zY_8SO05S-nlxfesI&usqp=CAU"),
                                    fit: BoxFit.cover)),
                          )),
                      Text(
                        "Tempura",
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        "A delicious egg food from Japan",
                        style: TextStyle(
                            fontSize: 11, fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.timer_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "10 min",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.star_border_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "4.5",
                            style: TextStyle(fontSize: 11),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.car_crash_outlined,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Delivery fastest",
                            style: TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Row(children: [
              Icon(
                Icons.apps_outlined,
                size: 25,
              ),
              Spacer(),
              Icon(
                Icons.add_box_outlined,
                size: 25,
                color: Colors.amber,
              ),
              Spacer(),
              Icon(
                Icons.lunch_dining_outlined,
                size: 25,
              ),
              Spacer(),
              Icon(
                Icons.person_2_outlined,
                size: 25,
              )
            ])
          ],
        ),
      ),
    );
  }
}
